// ----------------------------------------------------------------------

export const account = {
  displayName: 'Admin',
  email: 'admin@admin.com',
  photoURL: '/assets/images/avatars/avatar_25.jpg',
};
