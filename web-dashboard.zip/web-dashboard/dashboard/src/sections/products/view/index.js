export { default as ProductsView } from './products-view';
