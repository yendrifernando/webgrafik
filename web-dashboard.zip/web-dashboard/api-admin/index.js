const express = require("express");
const { google } = require("googleapis");
const cors = require("cors");
const bodyParser = require("body-parser");
const secure = require("ssl-express-www");

const app = express();

const credentials = {
  client_email: "piyo-89@piyow-2023.iam.gserviceaccount.com",
  private_key:
    "-----BEGIN PRIVATE KEY-----\nMIIEvAIBADANBgkqhkiG9w0BAQEFAASCBKYwggSiAgEAAoIBAQDTXYtnK/F4pa7I\n4PBLZ4pCStJukLqYnmvXrRza2NEuxM0rUnvtbDTdyrH1hj/ykHrJbpEum7VvI+sR\nIBkrDq1Mr7TmvQeVUf03rtH0h1xvSw875F3F7pJK/xlV3dJHsaUWDpkWYePGcRN7\nLPcXMhqmaqzljlrt3MD4lA8PrUmjL8DPLUMnyeMTQqVRXBxeutLcFGVicvBI+FkR\n4T902Ckz+t18S6GPoc6PsgfIfxYmC1CF2Rq14NeHODod7ZQgDeCTCdB1t0TI6Zzj\nsNaz3tNlItbgv3wN6LI4gC39pBVKwmp+caotfDcvXKgwRXfHdLOGR87Ns8MrrMj8\n41gQyzh5AgMBAAECggEAYdF3BIZnuEglPb4sNxlx+QAbpyO/14XpruTk57tUA+r8\ncMI5rEVZqhN2jIRW7/FBghtzgTh6nTboQQKz4yNlvInMlMSCz+4j3DNB44MJmlAI\netVTOJkShzbMCNshyCBEoJKc8qjW+y21sFm8+LUtdDsGTS62kkKJ5ADRf5XY8HX/\n3DWzKUmX80RSzTZFoiRipXKypstoalDB2TNxXgXkTxPXgE/XVgrLkgb5yO7imcUC\nTZsRX92UfVOkHeKl9s915frTLpteFGCeoY4v5O379X7/93w8zu05ESfe0E3thHMk\n7bsQjZEvEUYLf2u6ShUZL4gt2X7vGRHpr7Ujry4zSQKBgQDphh2nGDW4FjoMwVnK\nlThUxHJcz4Lzm/x+y1RMj2feTn07wf/0YaRecp/o4fOcVkaMH3Q5IkBWXctiqGWy\n+zMe82R2wvE92F1ZzxUUHPXO9Yh8NRbhfiWCDy1KplGDfhCNgTMhrJUHt2HenYAI\nQgtBf2OTVuBn4/GjPJPJ4islFwKBgQDntXUadQ+TBMND5DgcrRT+8jrwxq1Y+7Tv\nLLHlf0xQ/8o/5rK4jvQFiXnOJIsB0Ot5gsJpDjVkSaZcHSKyOCvUZmV61yoO15M1\nXyXeNtd0H/egSJls3y/rJhdzTPOMSw9n7d2iTyg0oWEYsu+fpoD3f92wDANYG0Zg\nGFaMnAgo7wKBgGk7q88pxMNxGLW4x9rXxavFXvfd91gKOg11WUaq9Raj7iFougwJ\nmEWLh+4tLFeONXpdjkVU3wNMfyO1WSb/tjjDW8l87bN99gtLm2cV6dtaoCfA0M/K\nxeJHLpTOQDtuKs1ppH4PRJVWmT71YMXX5TSd0GSMKNIIUVLLMJowVlr/AoGAJ/56\nKAbsmUPJMH7D8K8vYJIO+mBQq3tGz8G3MxW15oVAM6duUcza8dm43IwSMk4NVvvq\n8pcxQA42WM/unTR03ESQX5Oj/svW7O9vadutdK3P4Cqn0NL1QnFgutYdc6nBDv9P\nsiRXnD3+tHSuR7BFsnKvoSNxsFOE4jFRPxPvlKECgYA9hrdfxLuaqZj0zr3TqSmp\nldmb30ghkq3PKfCeTQ0gRO+n4Q/tvwk2aGpQbQqgQgvjOcuIlmiSUMml3/s4O2Cw\nnBJ7AbHSPD7L7N4N5q76bXHYaGrbNTUO4iShgp/BjRPhCYi6siHi52PrVUWXJNtS\n0H3Zwl3qJASKEcv2JrZx7g==\n-----END PRIVATE KEY-----\n", // Ganti dengan kunci privat Anda
};

const auth = new google.auth.JWT({
  email: credentials.client_email,
  key: credentials.private_key,
  scopes: ["https://www.googleapis.com/auth/spreadsheets"],
});
const sheets = google.sheets("v4");
const idSpreadsheet = "1x9SuIJX-exomHII54_YMcwtiLRSx7YAM1tim1zYxBoE";

async function getSpreadsheetData(sheetName) {
  try {
    await auth.authorize();
    const response = await sheets.spreadsheets.values.get({
      auth,
      spreadsheetId: idSpreadsheet,
      range: `${sheetName}!A:AB`,
    });
    return response.data.values;
  } catch (error) {
    throw new Error(`Error getting spreadsheet data: ${error.message}`);
  }
}

async function convertToJSON(sheetName) {
  const data = await getSpreadsheetData(sheetName);

  const headers = data[0];
  const jsonData = [];

  for (let i = 1; i < data.length; i++) {
    const row = data[i];
    const rowData = {};

    let skipRow = false; 

    for (let j = 0; j < headers.length; j++) {
      rowData[headers[j]] = row[j];
      if (headers[j] === 'laporan' && !row[j]) {
        skipRow = true;
        break;
      }
    }

    if (!skipRow) {
      jsonData.push(rowData);
    }
  }

  return jsonData;
}

function hitungJumlahLaporan(data) {
  const jumlahLaporan = {};

  data.forEach(item => {
    const kategori = item.laporan;
    if (jumlahLaporan[kategori]) {
      jumlahLaporan[kategori]++;
    } else {
      jumlahLaporan[kategori] = 1;
    }
  });

  return jumlahLaporan;
}

function countCategoriesByReportType(data) {
  const countsByReportType = {};

  data.forEach(entry => {
    const reportType = entry['laporan'];
    const timestamp = entry['timestamp'];

    if (!timestamp || !reportType) return;

    const [, time] = timestamp.split(', ');
    const [hourStr, minuteStr] = time.split(':');
    const hour = parseInt(hourStr);
    const minute = parseInt(minuteStr);

    let category;
    if (reportType === 'Briefing Pagi' && (hour < 9 || (hour === 9 && minute <= 0))) {
      category = 'TEPAT_WAKTU';
    } else if (reportType === 'Lunch' && (hour < 15 || (hour === 15 && minute <= 0))) {
      category = 'TEPAT_WAKTU';
    } else if (reportType === 'Coffe break' && (hour < 19 || (hour === 19 && minute <= 0))) {
      category = 'TEPAT_WAKTU';
    } else {
      category = 'TERLAMBAT';
    }

    if (countsByReportType[reportType]) {
      if (countsByReportType[reportType][category]) {
        countsByReportType[reportType][category]++;
      } else {
        countsByReportType[reportType][category] = 1;
      }
    } else {
      countsByReportType[reportType] = { [category]: 1 };
    }
  });
  
  for (const reportType in countsByReportType) {
    if (!Object.keys(countsByReportType[reportType]).length) {
      delete countsByReportType[reportType];
    }
  }

  return countsByReportType;
}

function countCategoriesByReportTypeArea(data) {
  const countsByAreaAndCategory = {};

  data.forEach(entry => {
    const up3 = entry['area (ulp)'].toLowerCase();
    const reportType = entry['laporan'];
    const kategori = entry['KATEGORI'];

    if (!up3 || !kategori) return;

    if (!countsByAreaAndCategory[up3]) {
      countsByAreaAndCategory[up3] = {};
    }

    if (!countsByAreaAndCategory[up3][reportType]) {
      countsByAreaAndCategory[up3][reportType] = { total: 0, terlambat: 0, tepatWaktu: 0 };
    }

    countsByAreaAndCategory[up3][reportType].total++;

    if (kategori === 'TERLAMBAT') {
      countsByAreaAndCategory[up3][reportType].terlambat++;
    } else if (kategori === 'TEPAT WAKTU') {
      countsByAreaAndCategory[up3][reportType].tepatWaktu++;
    }
  });

  return countsByAreaAndCategory;
}

function countCategoriesByReportTypeAreaUP3(data) {
  const countsByAreaAndCategory = {};

  data.forEach(entry => {
    const up3 = entry['up3'].toLowerCase();
    const reportType = entry['laporan'];
    const timestamp = entry['timestamp'];

    if (!up3 || !timestamp) return;

    const [, time] = timestamp.split(', '); 
    const [hourStr, minuteStr] = time.split(':');
    const hour = parseInt(hourStr);
    const minute = parseInt(minuteStr);

    let category;
    if (reportType === 'Briefing Pagi' && (hour < 9 || (hour === 9 && minute <= 0))) {
      category = 'TEPAT_WAKTU';
    } else if (reportType === 'Lunch' && (hour < 15 || (hour === 15 && minute <= 0))) {
      category = 'TEPAT_WAKTU';
    } else if (reportType === 'Coffe break' && (hour < 19 || (hour === 19 && minute <= 0))) {
      category = 'TEPAT_WAKTU';
    } else {
      category = 'TERLAMBAT';
    }

    if (!countsByAreaAndCategory[up3]) {
      countsByAreaAndCategory[up3] = {};
    }

    if (!countsByAreaAndCategory[up3][reportType]) {
      countsByAreaAndCategory[up3][reportType] = { total: 0, terlambat: 0, tepatWaktu: 0 };
    }

    countsByAreaAndCategory[up3][reportType].total++;

    if (category === 'TERLAMBAT') {
      countsByAreaAndCategory[up3][reportType].terlambat++;
    } else if (category === 'TEPAT_WAKTU') {
      countsByAreaAndCategory[up3][reportType].tepatWaktu++;
    }
  });

  return countsByAreaAndCategory;
}

function restructureData(data) {
  const areaData = [];

  data.forEach(item => {
      const area = item['up3'];
      const laporan = item.laporan.toLowerCase();

      const areaIndex = areaData.findIndex(areaItem => areaItem.area === area);

      if (areaIndex === -1) {
        areaData.push({
          area: area,
          [laporan]: 1 
        });
      } else {
        if (!areaData[areaIndex][laporan]) {
          areaData[areaIndex][laporan] = 1;
        } else {
          areaData[areaIndex][laporan]++;
        }
      }
  });

  return areaData;
}

function restructureDataUP3(data) {
  const areaData = [];

  data.forEach(item => {
    if (item.cat === "ULP") {
      const area = item['up3'].toLowerCase();
      const laporan = item.laporan.toLowerCase();

      const areaIndex = areaData.findIndex(areaItem => areaItem.area === area);

      if (areaIndex === -1) {
        areaData.push({
          area: area,
          [laporan]: 1 
        });
      } else {
        if (!areaData[areaIndex][laporan]) {
          areaData[areaIndex][laporan] = 1;
        } else {
          areaData[areaIndex][laporan]++;
        }
      }
    }
  });

  return areaData;
}



app.use(cors());
app.use(secure);
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: true }));

app.set("json spaces", 2);
app.use((req, res, next) => {
  res.setHeader("Content-Type", "application/json");
  next();
});

app.get("/api/sheet/:sheetName", async (req, res) => {
  const { sheetName } = req.params;
  try {
    const jsonData = await convertToJSON(sheetName);
    res.jsonp(jsonData);
  } catch (error) {
    console.error("Error:", error);
    res.status(500).json({ error: "Internal Server Error" });
  }
});

app.get('/api/up3', async (req,res) => {
  const data = await convertToJSON("Daftar1");
  const result = await restructureDataUP3(data);
  res.jsonp(result);
})

app.get('/api/ulp', async (req,res) => {
  const data = await convertToJSON("Daftar1");
  const result = await hitungJumlahLaporan(data)
  res.jsonp(result);
})

app.get('/api/ulp/status', async (req, res) => {
  try {
    const data = await convertToJSON("Daftar1");
    const counts = countCategoriesByReportType(data);
    res.json(counts);
  } catch (error) {
    console.error("Error fetching data:", error);
    res.status(500).json({ error: "Internal server error" });
  }
});

app.get('/api/ulp/areastatus', async (req,res) => {
  try {
    const data = await convertToJSON("Daftar1");
    const counts = await countCategoriesByReportTypeArea(data);
    res.json(counts);
  } catch (error) {
    console.error("Error Fetching data", error);
    res.status(500).json({ error: "Internal server error"});
  }
})

app.get('/api/up3/areastatus', async (req,res) => {
  try {
    const data = await convertToJSON("Daftar1");
    const counts = await countCategoriesByReportTypeAreaUP3(data);
    res.json(counts);
  } catch (error) {
    console.error("Error Fetching data", error);
    res.status(500).json({ error: "Internal server error"});
  }
})

app.get('/api/up3/area', async (req,res) => {
  const data = await convertToJSON("Daftar1");
  const result = await restructureData(data)
  res.json(result);
})

app.get("/api/daftardashboard", async (req, res) => {
  const { tahun } = req.query;
  const data = await convertToJSON("Daftar1");

  let obj;

  if (tahun === "semua") {
    res.jsonp({
      status: "success",
      data: data.map((item) => {
        const waktuComponents = item.waktu
          ? item.waktu.split("/")
          : ["", "", ""];
        const [day, month, year] = waktuComponents;
        return {
          ...item,
          bulan: item.waktu ? parseInt(month) : "",
          tahun: item.waktu ? parseInt(year) : "",
        };
      }),
      statistik: {
        total: data.length,
        tahun: "Semua",
      },
    });
    return;
  }

  obj = {
    status: "success",
    data: data
      .filter((item) => {
        const waktuComponents = item.waktu
          ? item.waktu.split("/")
          : ["", "", ""];
        const [day, month, year] = waktuComponents;
        return parseInt(year.split(',')[0]) === parseInt(tahun);
      })
      .map((item) => {
        const waktuComponents = item.waktu
          ? item.waktu.split("/")
          : ["", "", ""];
        const [day, month, year] = waktuComponents;
        return {
          ...item,
          bulan: item.waktu ? parseInt(month) : "",
          tahun: item.waktu ? parseInt(year) : "",
        };
      }),
    statistik: {
      total: data.length,
      tahun: parseInt(tahun),
    },
  };

  return res.jsonp(obj);
});

const PORT = process.env.PORT || 3000;
app.listen(PORT, () => {
  console.log(`Server is running on port ${PORT}`);
});
